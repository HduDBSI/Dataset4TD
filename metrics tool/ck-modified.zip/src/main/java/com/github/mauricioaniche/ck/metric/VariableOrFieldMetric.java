package com.github.mauricioaniche.ck.metric;

public interface VariableOrFieldMetric {
}
