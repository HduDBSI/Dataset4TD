package cbo;

public class A {

	public void method(){}
}
