package fieldusage;

class FieldUsage2 {
	public int a = 10;
	public int x = 10;
}