package dit;

public class D extends C {

}
