package dit;

public class C extends B {

}
