package numbers;

class Numbers {
	

	public void m1() {
		int a = 10;
		double b = 10.0;
		long a = 10L;
		float f = 10.0f;

		f = 30.0;
	}

	public void m2() {
		
	}
}