package bind;

import a.b.c.d.SomeClass;
import x.y.z.A1;
import x.y.z.B2;

public class BindingFail1 extends SomeClass implements A1, B2, Int1 {

	public void a() {

	}

	public void x() {

	}

}