package methods;

public class Methods3 {

	private int k;

	public Methods3() {
		// ...
	}

	public Methods3(int k) {
		this.k = k;
	}

	private int a() {
		return 10;
	}

}