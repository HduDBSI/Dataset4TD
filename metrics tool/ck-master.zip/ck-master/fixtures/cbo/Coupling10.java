package cbo;

class Coupling10 {


    private B f3;

    public B f3() {
        return f3;
    }

    public A f3() {
        return f3;
    }


}