package cbo;

import dit.C2;

public class CouplingHelper {

	public C2 m1() {
		return new C2();
	}
}
