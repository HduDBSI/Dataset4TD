package cbo;

class Coupling0 {
	
	public String method() {
		int a = 0;
		
		return "hey";
	}
	
	public void x() {
		throw new RuntimeException();
	}
}