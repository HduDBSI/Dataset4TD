package cbo;

class Coupling12 {
    public A sampleMethod() {
        return SampleClassWithStaticMethod.sampleMethod();
    }
}