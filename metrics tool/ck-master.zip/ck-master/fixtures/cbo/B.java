package cbo;

public class B extends A {

public void method(){}
}
