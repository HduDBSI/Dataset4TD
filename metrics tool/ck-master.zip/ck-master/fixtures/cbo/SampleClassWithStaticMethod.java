package cbo;

class SampleClassWithStaticMethod {
    static B ss;
    public static B sampleMethod() {
        return ss;
    }
}