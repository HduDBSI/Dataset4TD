package rfc;

public class GO2 {

	public void magic() {
		
	}
}
