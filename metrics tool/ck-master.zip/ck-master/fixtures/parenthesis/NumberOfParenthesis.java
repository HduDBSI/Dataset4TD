package parenthesis;

public class NumberOfParenthesis {

    private int c = 4;
    private int d = c * 4;

    public D m1() {
        int a = 0;
        int b = 2;
        a = 2+((b*2)/3);

        return a;
    }
}