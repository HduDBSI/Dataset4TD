package jdt;

public class A {

	
}
