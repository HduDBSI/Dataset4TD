package nosi;

import java.util.Calendar;

public class Class1 {
	
	public void a() {
		a();
		
		int x = Undetected.inv();
	}
}