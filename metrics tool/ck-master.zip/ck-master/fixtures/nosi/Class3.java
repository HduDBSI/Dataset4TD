package nosi;

import java.util.Calendar;

public class Class3 {
	
	private static int x() {
		
	}
	
	public void a() {
		a();
		
		int aaa = Class3.x();
		int aaas = x();
	}
}