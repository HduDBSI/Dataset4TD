package nestedblocks;

class NestedBlocks5 {

	public void m1() {
		int a = 0;

		if(a > 10) {
			{
				{
					int b = 10;
				}
			}
		}

	}


}